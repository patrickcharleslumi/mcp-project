# Luminance HubSpot Integration - Working Backup

**Date:** February 20, 2026
**Status:** ✅ WORKING END-TO-END

## What's in This Backup

This folder contains the **current deployed and working** version of the Luminance HubSpot integration.

### Contents

1. **luminance-card-static/** - HubSpot CRM Card App
   - Build #23 (currently deployed to developer account 147843696)
   - Calls middleware via `hubspot.fetch()`
   - No custom headers (only method and body)

2. **luminance-hubspot-middleware/** - Vercel Serverless Middleware
   - Deployed at: https://luminance-hubspot-middleware.vercel.app/api/trigger
   - Validates requests (signature validation currently disabled)
   - Calls Prismatic endpoint
   - Updates HubSpot deal properties
   - Manages OAuth tokens via Vercel KV

## Current Architecture (WORKING)

```
Card → hubspot.fetch(Middleware) → Middleware calls Prismatic → Middleware updates HubSpot properties → Response to Card
```

### Card Flow:
1. User fills out form (action type, contract type, notes)
2. Card sends to middleware: `{dealId, action, contractType, notes, attachmentId, portalId}`
3. Card receives response and starts polling for contract URL

### Middleware Flow:
1. Receives request from card
2. Gets OAuth token from Vercel KV
3. Calls Prismatic: https://hooks.eu-central-1.integrations.luminance.com/trigger/SW5zdGFuY2VGbG93Q29uZmlnOjRhN2Q4ZjBiLTFlYjktNDZkZi04YmUzLTA1YmEwMzk4NmM3ZA==
4. On Prismatic success, updates deal properties
5. Returns success to card

### Deal Properties Used:
- `luminance_trigger_action` - "generate" or "upload"
- `luminance_contract_type` - "NDA" or "DPA"
- `luminance_trigger_timestamp` - timestamp
- `luminance_notes` - optional notes
- `luminance_attachment_id` - for uploads
- `luminance_contract_url` - returned by Prismatic (card polls for this)
- `luminance_contract_id` - matter ID from Luminance
- `luminance_contract_status` - "generated", "uploaded", etc.

## Deployment Info

### Card (luminance-card-static)
- **Developer Account:** 147843696
- **Test Portal:** 147788687
- **App ID:** 31758382
- **Build:** #23
- **Platform Version:** 2025.2

### Middleware (luminance-hubspot-middleware)
- **URL:** https://luminance-hubspot-middleware.vercel.app
- **Endpoint:** /api/trigger
- **Project:** patrickcharles-5611s-projects/luminance-hubspot-middleware

### Vercel Environment Variables
```
HUBSPOT_CLIENT_ID=<set>
HUBSPOT_CLIENT_SECRET=<set>
KV_REST_API_URL=<set>
KV_REST_API_TOKEN=<set>
KV_REST_API_READ_ONLY_TOKEN=<set>
KV_URL=<set>
REDIS_URL=<set>
```

## Known Issues (Minor)

1. **OAuth Token Expiration:** Tokens expire after a few hours. Current workaround: reinstall app to refresh tokens. Proper fix would be to add token refresh logic in middleware.

2. **Signature Validation Disabled:** HubSpot signature validation is temporarily disabled in middleware (line marked with `if (false &&...`). Should be re-enabled once we understand HubSpot's signature format.

## What's Working

✅ Card loads in HubSpot deals
✅ OAuth flow and token storage
✅ Card → Middleware communication via `hubspot.fetch()`
✅ Middleware → Prismatic API calls
✅ Middleware → HubSpot property updates
✅ Card polling for contract URL
✅ End-to-end contract generation flow

## Testing Steps

1. Open a Deal in test portal 147788687
2. Ensure Deal has: dealname and amount fields filled
3. Fill out card: Action = "Generate", Contract Type = "NDA"
4. Click "Generate Contract in Luminance"
5. Card polls and displays success with contract link

## Important Files

### Card
- `src/app/cards/ContractCardV2.jsx` - Main card component
- `src/app/app-hsmeta.json` - App configuration with permittedUrls

### Middleware
- `api/trigger.js` - Main handler
- `api/oauth-callback.js` - OAuth installation handler
- `vercel.json` - Vercel configuration

## Do NOT Change Without Testing

⚠️ This is a working state. Before making changes:
1. Test the change in development
2. Document what you're changing
3. Keep this backup safe

## Next Steps (Optional Improvements)

1. Add OAuth token refresh logic
2. Re-enable signature validation
3. Add better error handling
4. Add logging/monitoring
5. Create deal properties automatically on install
6. Add retry logic for transient failures

---

**This backup was created before making changes to add token refresh logic.**
