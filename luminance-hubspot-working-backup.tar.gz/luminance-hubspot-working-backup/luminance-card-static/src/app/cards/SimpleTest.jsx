import React from 'react';
import { hubspot, Text } from '@hubspot/ui-extensions';

hubspot.extend(() => <Text>Hello from Luminance!</Text>);
